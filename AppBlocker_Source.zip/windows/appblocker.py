import tkinter as tk
from tkinter import messagebox
import json, os, time, subprocess, sys
from datetime import datetime
try:
    import psutil
except ImportError:
    psutil = None

CONFIG = os.path.join(os.path.dirname(__file__), "block_rules.json")
DAYS = ["월", "화", "수", "목", "금", "토", "일"]

def load():
    try:
        with open(CONFIG, encoding="utf-8") as f: return json.load(f)
    except Exception: return {"rules": []}

def save():
    rules = []
    for name, var in app_vars.items():
        if var.get():
            rules.append({"process": name, "days": [i for i,v in enumerate(day_vars) if v.get()],
                          "start": start.get(), "end": end.get(), "enabled": True})
    os.makedirs(os.path.dirname(CONFIG), exist_ok=True)
    with open(CONFIG, "w", encoding="utf-8") as f: json.dump({"version":1,"rules":rules}, f, ensure_ascii=False, indent=2)
    messagebox.showinfo("AppBlocker", "설정을 저장했어.")

def active(rule, now):
    try:
        a = datetime.strptime(rule["start"], "%H:%M").time()
        b = datetime.strptime(rule["end"], "%H:%M").time()
        t = now.time()
        time_ok = a <= t < b if a < b else (t >= a or t < b)
        return now.weekday() in rule["days"] and time_ok and rule.get("enabled", True)
    except Exception: return False

def enforcement_loop():
    if psutil:
        now = datetime.now()
        for rule in load().get("rules", []):
            if not active(rule, now): continue
            target = rule.get("process", "").lower()
            if not target: continue
            for proc in psutil.process_iter(["name"]):
                try:
                    if (proc.info["name"] or "").lower() == target:
                        proc.terminate()
                except (psutil.NoSuchProcess, psutil.AccessDenied): pass
    root.after(2500, enforcement_loop)

root = tk.Tk()
root.title("AppBlocker - Windows")
root.geometry("440x620")
tk.Label(root, text="AppBlocker", font=("맑은 고딕", 22, "bold")).pack(pady=12)
tk.Label(root, text="차단할 프로그램의 실행 파일 이름을 선택하거나 직접 입력해.").pack()
entry = tk.Entry(root, width=38); entry.pack(pady=6)
app_vars = {}
def add_process():
    name = entry.get().strip()
    if name and name not in app_vars:
        v = tk.BooleanVar(value=True); app_vars[name] = v
        tk.Checkbutton(list_frame, text=name, variable=v).pack(anchor="w")
        entry.delete(0, "end")
tk.Button(root, text="목록에 추가", command=add_process).pack()
list_frame = tk.Frame(root); list_frame.pack(fill="x", padx=24, pady=8)
tk.Label(root, text="적용 요일").pack()
day_frame = tk.Frame(root); day_frame.pack()
day_vars = []
for d in DAYS:
    v = tk.BooleanVar(value=len(day_vars)<5); day_vars.append(v)
    tk.Checkbutton(day_frame, text=d, variable=v).pack(side="left")
tk.Label(root, text="시작 시간 / 종료 시간 (HH:MM)").pack(pady=(12,2))
time_frame = tk.Frame(root); time_frame.pack()
start=tk.Entry(time_frame,width=10); start.insert(0,"16:00"); start.pack(side="left",padx=5)
end=tk.Entry(time_frame,width=10); end.insert(0,"18:00"); end.pack(side="left",padx=5)
tk.Button(root, text="설정 저장", command=save).pack(pady=12)
tk.Label(root, text="프로그램을 켜 둬야 차단 감시가 작동해.\nWindows 시스템 프로세스는 차단하지 마.", justify="center").pack(pady=8)
tk.Label(root, text="설정 파일: windows/block_rules.json", fg="gray").pack()
root.after(1500, enforcement_loop)
root.mainloop()
