package com.example.appblocker

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Calendar

class BlockAccessibilityService : AccessibilityService() {
    private var lastBlockedPackage = ""
    private var lastActionAt = 0L
    // 강력 모드: 차단 시간 동안 설정 앱과 앱 설치/삭제 화면도 막는다
    private val guarded = setOf(
        "com.android.settings", "com.samsung.android.settings",
        "com.google.android.packageinstaller", "com.android.packageinstaller",
        "com.samsung.android.packageinstaller"
    )

    // 집중 잠금 중에도 쓸 수 있는 앱: 전화, 긴급 통화, 알람
    private val allowedInLock = setOf(
        "com.android.dialer", "com.google.android.dialer", "com.samsung.android.dialer",
        "com.android.incallui", "com.samsung.android.incallui", "com.android.server.telecom",
        "com.android.emergency", "com.samsung.android.emergency",
        "com.sec.android.app.clockpackage", "com.google.android.deskclock", "com.android.deskclock"
    )
    private var currentPkg = ""
    private var overlay: View? = null
    private var kindView: TextView? = null
    private var timeView: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { refreshOverlay(); handler.postDelayed(this, 1000) }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.post(ticker)
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        hideOverlay()
        super.onDestroy()
    }

    private fun refreshOverlay() {
        val prefs = getSharedPreferences("rules", MODE_PRIVATE)
        val left = prefs.getLong("lock_until", 0L) - System.currentTimeMillis()
        if (left <= 0 || currentPkg in allowedInLock) { hideOverlay(); return }
        showOverlay(prefs.getString("lock_kind", "study") ?: "study", left)
    }

    private fun showOverlay(kind: String, leftMs: Long) {
        val sec = leftMs / 1000
        val label = when (kind) { "sleep" -> "취침 시간"; "test" -> "시험"; else -> "공부 시간" }
        val time = String.format("%d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)
        if (overlay == null) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setBackgroundColor(Color.rgb(11, 16, 32))
                setPadding(64, 64, 64, 64)
            }
            box.addView(TextView(this).apply { text = "\uD83D\uDD12"; textSize = 56f; gravity = Gravity.CENTER })
            kindView = TextView(this).apply { textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
            timeView = TextView(this).apply { textSize = 44f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
            box.addView(kindView); box.addView(timeView)
            box.addView(TextView(this).apply {
                text = "폰이 잠겨 있어. 시간이 끝나야 풀려.\n전화와 알람은 쓸 수 있어."
                textSize = 16f; setTextColor(Color.rgb(160, 170, 195)); gravity = Gravity.CENTER
                setPadding(0, 32, 0, 0)
            })
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.OPAQUE
            )
            if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            try {
                (getSystemService(WINDOW_SERVICE) as WindowManager).addView(box, lp)
                overlay = box
            } catch (_: Exception) { return }
        }
        kindView?.text = "$label 잠금"
        timeView?.text = time
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (_: Exception) {}
        overlay = null; kindView = null; timeView = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event?.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        currentPkg = pkg
        refreshOverlay()
        val prefs = getSharedPreferences("rules", MODE_PRIVATE)
        val selected = prefs.getStringSet("packages", emptySet()) ?: emptySet()
        val blocking = isBlockedNow(prefs)
        val strictHit = blocking && prefs.getBoolean("strict", false) && pkg in guarded
        if (!strictHit && (pkg !in selected || !blocking)) return

        val now = System.currentTimeMillis()
        if (pkg == lastBlockedPackage && now - lastActionAt < 1200) return
        lastBlockedPackage = pkg
        lastActionAt = now
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun isBlockedNow(prefs: android.content.SharedPreferences): Boolean {
        if (System.currentTimeMillis() < prefs.getLong("break_until", 0L)) return false
        val cal = Calendar.getInstance()
        val day = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7 // 월=0 ... 일=6
        if (!prefs.getBoolean("day_$day", day < 5)) return false
        val minute = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val start = toMinutes(prefs.getString("start", "16:00") ?: "16:00")
        val end = toMinutes(prefs.getString("end", "18:00") ?: "18:00")
        return if (start < end) minute in start until end else minute >= start || minute < end
    }

    private fun toMinutes(value: String): Int {
        val parts = value.split(":")
        return parts.getOrNull(0)?.toIntOrNull()?.times(60)
            ?.plus(parts.getOrNull(1)?.toIntOrNull() ?: 0) ?: 0
    }

    override fun onInterrupt() {}
}
