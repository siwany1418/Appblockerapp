package com.example.appblocker

import android.accessibilityservice.AccessibilityService
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.SharedPreferences
import android.os.PowerManager
import android.view.animation.DecelerateInterpolator
import android.view.accessibility.AccessibilityEvent
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Calendar

class BlockAccessibilityService : AccessibilityService() {
    private var lastBlockedPackage = ""
    private var lastActionAt = 0L
    // 강력 모드: 차단 시간 동안 설정 앱과 앱 설치/삭제 화면도 막는다
    private val guarded = setOf(
        "com.android.settings", "com.samsung.android.settings",
        "com.google.android.packageinstaller", "com.android.packageinstaller",
        "com.samsung.android.packageinstaller"
    )

    // 집중 잠금 중에도 쓸 수 있는 앱: 전화, 긴급 통화, 알람
    private val allowedInLock = setOf(
        "com.android.dialer", "com.google.android.dialer", "com.samsung.android.dialer",
        "com.android.incallui", "com.samsung.android.incallui", "com.android.server.telecom",
        "com.android.emergency", "com.samsung.android.emergency",
        "com.sec.android.app.clockpackage", "com.google.android.deskclock", "com.android.deskclock"
    )
    private var currentPkg = ""
    private var overlay: View? = null
    private var kindView: TextView? = null
    private var timeView: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var anims: List<ObjectAnimator> = emptyList()

    // 배터리 절약: 잠금 화면이 보이고 화면이 켜져 있을 때만 자주(15초) 확인하고, 그 외에는 드물게 확인한다
    private val ticker = object : Runnable {
        override fun run() {
            refreshOverlay()
            val awake = (getSystemService(POWER_SERVICE) as PowerManager).isInteractive
            val locked = getSharedPreferences("rules", MODE_PRIVATE).getLong("lock_until", 0L) > System.currentTimeMillis()
            handler.postDelayed(this, if (overlay != null && awake) 15_000L else if (locked) 30_000L else 60_000L)
        }
    }

    // 잠금이 시작/변경되면 바로 반영 (기다리지 않고)
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "lock_until" || key == "lock_kind") handler.post { handler.removeCallbacks(ticker); ticker.run() }
    }

    // 화면이 꺼지면 애니메이션을 멈추고, 켜지면 이어서 보여준다
    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i?.action == Intent.ACTION_SCREEN_OFF) anims.forEach { it.pause() }
            else { anims.forEach { it.resume() }; handler.removeCallbacks(ticker); ticker.run() }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        getSharedPreferences("rules", MODE_PRIVATE).registerOnSharedPreferenceChangeListener(prefsListener)
        try {
            registerReceiver(screenRx, IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF)
            })
        } catch (_: Exception) {}
        handler.post(ticker)
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        getSharedPreferences("rules", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefsListener)
        try { unregisterReceiver(screenRx) } catch (_: Exception) {}
        hideOverlay()
        super.onDestroy()
    }

    // 이름에 전화/알람 관련 글자가 들어간 앱도 허용 (기종마다 앱 이름이 달라서)
    private fun isAllowed(p: String): Boolean =
        p in allowedInLock || listOf("dialer", "incallui", "telecom", "emergency", "clockpackage", "deskclock").any { p.contains(it) }

    private fun refreshOverlay() {
        val prefs = getSharedPreferences("rules", MODE_PRIVATE)
        val left = prefs.getLong("lock_until", 0L) - System.currentTimeMillis()
        if (left <= 0 || isAllowed(currentPkg)) { hideOverlay(); return }
        showOverlay(prefs.getString("lock_kind", "study") ?: "study", left)
    }

    private fun showOverlay(kind: String, leftMs: Long) {
        val label = when (kind) { "sleep" -> "취침 시간"; "test" -> "시험"; else -> "공부 시간" }
        val min = (leftMs + 59_999) / 60_000
        val time = if (min >= 60) "${min / 60}시간 ${min % 60}분" else "${min}분"
        if (overlay == null) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.rgb(11, 16, 32))
                setPadding(64, 120, 64, 160)
            }
            val center = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            // 전화 버튼은 숨겨져 있다가, 자물쇠를 5번 누르면 나타난다 (잠금 화면이 다시 뜰 때마다 다시 숨겨짐)
            val phoneBtn = Button(this).apply {
                text = "\uD83D\uDCDE 전화"; textSize = 18f; visibility = View.GONE
                setOnClickListener {
                    try { startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                }
            }
            var taps = 0
            val lockIcon = TextView(this).apply {
                text = "\uD83D\uDD12"; textSize = 56f; gravity = Gravity.CENTER
                setOnClickListener { if (++taps >= 5) phoneBtn.visibility = View.VISIBLE }
            }
            // 자물쇠 뒤로 물결 같은 원 3개가 차례로 퍼져 나간다
            val d = resources.displayMetrics.density
            val rings = (0..2).map {
                View(this).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT)
                        setStroke((2 * d).toInt().coerceAtLeast(2), Color.rgb(143, 211, 200))
                    }
                    alpha = 0f
                }
            }
            val frame = FrameLayout(this)
            rings.forEach { frame.addView(it, FrameLayout.LayoutParams((80 * d).toInt(), (80 * d).toInt(), Gravity.CENTER)) }
            frame.addView(lockIcon, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
            center.addView(frame, LinearLayout.LayoutParams((200 * d).toInt(), (200 * d).toInt()))
            kindView = TextView(this).apply { textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
            timeView = TextView(this).apply { textSize = 40f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
            center.addView(kindView); center.addView(timeView)
            center.addView(TextView(this).apply {
                text = "폰이 잠겨 있어. 시간이 끝나야 풀려.\n알람은 그대로 울려."
                textSize = 16f; setTextColor(Color.rgb(160, 170, 195)); gravity = Gravity.CENTER
                setPadding(0, 32, 0, 0)
            })
            center.addView(phoneBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = 48 })
            box.addView(center, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.OPAQUE
            )
            if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            try {
                box.alpha = 0f
                (getSystemService(WINDOW_SERVICE) as WindowManager).addView(box, lp)
                overlay = box
                box.animate().alpha(1f).setDuration(400).start()
                anims = rings.mapIndexed { n, v ->
                    ObjectAnimator.ofPropertyValuesHolder(
                        v,
                        PropertyValuesHolder.ofFloat("scaleX", 1f, 2.4f),
                        PropertyValuesHolder.ofFloat("scaleY", 1f, 2.4f),
                        PropertyValuesHolder.ofFloat("alpha", 0.55f, 0f)
                    ).apply {
                        duration = 3600; startDelay = n * 1200L
                        repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.RESTART
                        interpolator = DecelerateInterpolator(); start()
                    }
                }
                if (!(getSystemService(POWER_SERVICE) as PowerManager).isInteractive) anims.forEach { it.pause() }
            } catch (_: Exception) { return }
        }
        kindView?.text = "$label 잠금"
        if (timeView?.text?.toString() != time) timeView?.text = time
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (_: Exception) {}
        anims.forEach { it.cancel() }; anims = emptyList()
        overlay = null; kindView = null; timeView = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        currentPkg = pkg
        refreshOverlay()
        val prefs = getSharedPreferences("rules", MODE_PRIVATE)
        val selected = prefs.getStringSet("packages", emptySet()) ?: emptySet()
        val blockedThis = pkg in selected && isBlockedNow(prefs, pkg)
        val strictHit = prefs.getBoolean("strict", false) && pkg in guarded && selected.any { isBlockedNow(prefs, it) }
        if (!strictHit && !blockedThis) return

        val now = System.currentTimeMillis()
        if (pkg == lastBlockedPackage && now - lastActionAt < 1200) return
        lastBlockedPackage = pkg
        lastActionAt = now
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun isBlockedNow(prefs: android.content.SharedPreferences, pkg: String? = null): Boolean {
        if (System.currentTimeMillis() < prefs.getLong("break_until", 0L)) return false
        val cal = Calendar.getInstance()
        val day = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7 // 월=0 ... 일=6
        if (!prefs.getBoolean("day_$day", day < 5)) return false
        val minute = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        // 앱별로 따로 정한 시간이 있으면 그걸 쓰고, 없으면 전체 시간을 쓴다
        val c = (if (pkg != null) prefs.getString("app_time_$pkg", "") else "").orEmpty().split("-")
        val start = if (c.size == 2) toMinutes(c[0]) else toMinutes(prefs.getString("start", "16:00") ?: "16:00")
        val end = if (c.size == 2) toMinutes(c[1]) else toMinutes(prefs.getString("end", "18:00") ?: "18:00")
        return if (start < end) minute in start until end else minute >= start || minute < end
    }

    private fun toMinutes(value: String): Int {
        val parts = value.split(":")
        return parts.getOrNull(0)?.toIntOrNull()?.times(60)
            ?.plus(parts.getOrNull(1)?.toIntOrNull() ?: 0) ?: 0
    }

    override fun onInterrupt() {}
}
