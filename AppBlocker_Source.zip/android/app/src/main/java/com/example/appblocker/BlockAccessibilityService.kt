package com.example.appblocker

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import java.util.Calendar

class BlockAccessibilityService : AccessibilityService() {
    private var lastBlockedPackage = ""
    private var lastActionAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event?.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        val prefs = getSharedPreferences("rules", MODE_PRIVATE)
        val selected = prefs.getStringSet("packages", emptySet()) ?: emptySet()
        if (pkg !in selected || !isBlockedNow(prefs)) return

        val now = System.currentTimeMillis()
        if (pkg == lastBlockedPackage && now - lastActionAt < 1200) return
        lastBlockedPackage = pkg
        lastActionAt = now
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun isBlockedNow(prefs: android.content.SharedPreferences): Boolean {
        val cal = Calendar.getInstance()
        val day = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7 // 월=0 ... 일=6
        if (!prefs.getBoolean("day_$day", day < 5)) return false
        val minute = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val start = toMinutes(prefs.getString("start", "16:00") ?: "16:00")
        val end = toMinutes(prefs.getString("end", "18:00") ?: "18:00")
        return if (start < end) minute in start until end else minute >= start || minute < end
    }

    private fun toMinutes(value: String): Int {
        val parts = value.split(":")
        return parts.getOrNull(0)?.toIntOrNull()?.times(60)
            ?.plus(parts.getOrNull(1)?.toIntOrNull() ?: 0) ?: 0
    }

    override fun onInterrupt() {}
}
