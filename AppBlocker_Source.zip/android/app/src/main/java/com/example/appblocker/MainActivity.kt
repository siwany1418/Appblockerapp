package com.example.appblocker

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.Calendar

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("rules", MODE_PRIVATE) }
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { refreshPage() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.addJavascriptInterface(Bridge(), "Native")
        web.setOnApplyWindowInsetsListener { v, ins ->
            v.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
            ins
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        refreshPage()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        registerReceiver(receiver, f)
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
    }

    private fun refreshPage() {
        runOnUiThread { web.evaluateJavascript("window.loadAll && loadAll()", null) }
    }

    private fun iconB64(d: Drawable): String {
        val s = 72
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, s, s)
        d.draw(Canvas(b))
        val o = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.PNG, 100, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    private fun selectedSet(): MutableSet<String> =
        (prefs.getStringSet("packages", emptySet()) ?: emptySet()).toMutableSet()

    private fun toMin(v: String): Int {
        val p = v.split(":")
        return (p.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0)
    }

    private fun isBlockedNow(): Boolean {
        if (System.currentTimeMillis() < prefs.getLong("break_until", 0L)) return false
        val cal = Calendar.getInstance()
        val day = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
        if (!prefs.getBoolean("day_$day", day < 5)) return false
        val minute = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val start = toMin(prefs.getString("start", "16:00") ?: "16:00")
        val end = toMin(prefs.getString("end", "18:00") ?: "18:00")
        return if (start < end) minute in start until end else minute >= start || minute < end
    }

    private fun serviceOn(): Boolean =
        Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true

    // 강력 모드가 켜져 있고 지금이 차단 시간이면 해제/변경을 막는다
    private fun locked(): Boolean =
        prefs.getBoolean("strict", false) && serviceOn() && isBlockedNow()

    inner class Bridge {
        @JavascriptInterface
        fun getApps(): String {
            val sel = selectedSet()
            val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
            val arr = JSONArray()
            packageManager.queryIntentActivities(intent, 0)
                .filter { it.activityInfo.packageName != packageName }
                .distinctBy { it.activityInfo.packageName }
                .forEach { ri ->
                    val pkg = ri.activityInfo.packageName
                    arr.put(JSONObject().apply {
                        put("pkg", pkg)
                        put("label", ri.loadLabel(packageManager).toString())
                        put("on", pkg in sel)
                        put("icon", iconB64(ri.loadIcon(packageManager)))
                    })
                }
            return arr.toString()
        }

        @JavascriptInterface
        fun setBlocked(pkg: String, on: Boolean): String {
            if (!on && locked()) return "locked"
            val s = selectedSet()
            if (on) s.add(pkg) else s.remove(pkg)
            prefs.edit().putStringSet("packages", s).apply()
            return "ok"
        }

        @JavascriptInterface
        fun startBreak(): String {
            val now = System.currentTimeMillis()
            if (now - prefs.getLong("break_last", 0L) < 3_600_000L) return "cool"
            prefs.edit().putLong("break_until", now + 900_000L).putLong("break_last", now).apply()
            return "ok"
        }

        @JavascriptInterface
        fun endBreak(): String {
            prefs.edit().putLong("break_until", 0L).apply()
            return "ok"
        }

        @JavascriptInterface
        fun startLock(kind: String): String {
            if (!serviceOn()) return "noservice"
            val now = System.currentTimeMillis()
            if (prefs.getLong("lock_until", 0L) > now) return "already"
            val ms = when (kind) { "sleep" -> 8 * 3_600_000L; "test" -> 60_000L; else -> 2 * 3_600_000L }
            prefs.edit().putLong("lock_until", now + ms).putString("lock_kind", kind).apply()
            return "ok"
        }

        @JavascriptInterface
        fun getStrict(): Boolean = prefs.getBoolean("strict", false)

        @JavascriptInterface
        fun setStrict(on: Boolean): String {
            if (!on && locked()) return "locked"
            prefs.edit().putBoolean("strict", on).apply()
            return "ok"
        }

        @JavascriptInterface
        fun getSchedule(): String {
            val days = JSONArray()
            for (i in 0..6) days.put(prefs.getBoolean("day_$i", i < 5))
            return JSONObject().apply {
                put("days", days)
                put("start", prefs.getString("start", "16:00"))
                put("end", prefs.getString("end", "18:00"))
            }.toString()
        }

        @JavascriptInterface
        fun saveSchedule(daysJson: String, start: String, end: String): String {
            if (locked()) return "locked"
            val ok = Regex("^([01]\\d|2[0-3]):[0-5]\\d$")
            if (!ok.matches(start) || !ok.matches(end) || start == end) return "bad"
            val days = JSONArray(daysJson)
            val e = prefs.edit().putString("start", start).putString("end", end)
            for (i in 0..6) e.putBoolean("day_$i", days.optBoolean(i, i < 5))
            e.apply()
            return "ok"
        }

        @JavascriptInterface
        fun getStatus(): String {
            val enabled = serviceOn()
            return JSONObject().apply {
                put("strict", prefs.getBoolean("strict", false))
                val left = prefs.getLong("break_until", 0L) - System.currentTimeMillis()
                put("breakLeft", if (left > 0) ((left + 59_999) / 60_000).toInt() else 0)
                val lockLeft = prefs.getLong("lock_until", 0L) - System.currentTimeMillis()
                put("lockLeft", if (lockLeft > 0) ((lockLeft + 59_999) / 60_000).toInt() else 0)
                put("lockKind", prefs.getString("lock_kind", "study"))
                put("enabled", enabled)
                put("blocking", enabled && selectedSet().isNotEmpty() && isBlockedNow())
            }.toString()
        }

        @JavascriptInterface
        fun openAccessibility() {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        @JavascriptInterface
        fun openDetails() {
            val i = Intent("android.settings.ACCESSIBILITY_DETAILS_SETTINGS")
            i.data = Uri.parse("package:$packageName")
            try { startActivity(i) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
    }
}
