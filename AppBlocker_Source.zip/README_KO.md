# AppBlocker (Android + Windows 소스 프로젝트)

## 현재 포함된 기능
- Android: 설치된 앱 자동 인식(설치/삭제 시 자동 갱신, 검색 가능) + HTML 화면(WebView)에서 앱별 스위치로 차단 켜기/끄기, 강력 모드(차단 시간 동안 해제·설정·삭제 잠금), 숨겨진 비상 15분 쉬기(제목을 7번 탭), 집중 잠금(공부·취침 시간 설정 가능, 기본 2시간·8시간, 중간 해제 불가), 앱별 차단 시간 설정, 15분 쉬기(1시간에 1번)(즉시 저장, 차단 ON 앱 행 색상 변경, 상태 배너 색상: 꺼짐 회색·차단 중 빨강·대기 초록), 요일별 차단 시간 설정, 접근성 서비스로 선택 앱 진입 감지 후 홈 화면으로 이동
- Windows: Python 보조 프로그램에서 설정한 프로세스 이름을 감지해 종료
- 설정 파일 형식은 `shared/block_rules.json`으로 통일

## Android APK 빌드
1. Android Studio에서 `android` 폴더를 엽니다.
2. Gradle 동기화가 끝나면 Build > Build Bundle(s) / APK(s) > Build APK(s)를 선택합니다.
3. 앱을 설치한 뒤 앱 안의 안내에 따라 접근성 서비스 `AppBlocker`를 직접 켭니다.
4. 앱 목록에서 차단할 앱을 고르고 요일 및 시작/종료 시간을 저장합니다.

필요 환경: Android Studio, JDK 17, Android SDK 35.

## Windows 실행
1. Python 3.10 이상 설치
2. `pip install -r windows/requirements.txt`
3. `python windows/appblocker.py`
4. 차단할 프로세스 이름을 입력하고 요일/시간을 설정합니다.

## 중요 제한
- 운영체제 정책상 사용자가 접근성 권한을 직접 허용해야 합니다.
- Android 앱은 현재 기기 안에서 동작하며 PC와 자동 클라우드 동기화는 아직 연결되어 있지 않습니다.
- Android는 접근성 서비스가 꺼지거나 기기가 재부팅된 직후에는 차단이 보장되지 않을 수 있습니다.
- Windows 보조 프로그램은 관리자 권한, 작업 관리자, 안전 모드 등으로 우회될 수 있습니다. 시스템 핵심 프로세스는 차단하지 않습니다.
- 이 프로젝트는 사용자가 직접 선택한 앱만 제한하는 자기관리 도구이며, OS 수준의 변조나 보안 우회 기능은 포함하지 않습니다.


## HTML 관리 화면
- `web/index.html`을 브라우저에서 열면 규칙 관리 화면을 사용할 수 있습니다.
- 브라우저 로컬 저장소에 규칙을 저장하고 `block_rules.json`으로 내보내거나 가져올 수 있습니다.
- HTML은 관리 화면이며 자체적으로 다른 앱을 강제 차단하지 않습니다. 실제 차단은 Android/Windows 네이티브 구성요소가 담당합니다.


## Android Studio 없이 APK 만들기 (GitHub Actions)
1. GitHub에 새 저장소를 만들고 이 프로젝트의 모든 파일(`.github` 폴더 포함)을 올립니다.
2. 저장소의 Actions 탭 > Build APK 가 자동 실행됩니다(안 되면 Run workflow).
3. 끝나면 실행 결과 화면 아래 Artifacts 의 `AppBlocker-apk`를 받아 압축을 풀면 `app-debug.apk`가 있습니다.
4. 폰에 설치하고 접근성 서비스를 직접 켭니다.
