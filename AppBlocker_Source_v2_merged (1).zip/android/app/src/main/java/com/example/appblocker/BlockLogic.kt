package com.example.appblocker

import android.content.SharedPreferences
import org.json.JSONArray
import java.util.Calendar

// 이름 붙인 자동 차단 규칙 (학원, 수면 ...)
class Rule(
    val id: String,
    val name: String,
    val days: BooleanArray,
    val start: String,
    val end: String,
    val apps: Set<String>,
    val on: Boolean,
    val sites: Set<String> = emptySet()
)

// 앱 화면(MainActivity)과 접근성 서비스가 같은 판단 기준을 쓰도록 모아둔 곳
object BlockLogic {
    const val PAUSE_MS = 30 * 60_000L // 기간 차단 중 '30분만 풀기' 길이

    private val TIME = Regex("^([01]\\d|2[0-3]):[0-5]\\d$")

    private val DOMAIN = Regex("^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$")

    fun validTime(v: String): Boolean = TIME.matches(v)

    // 주소 입력을 도메인으로 정리한다. "https://www.youtube.com/watch?v=1" -> "youtube.com". 잘못된 주소면 빈 문자열.
    fun normalizeSite(raw: String): String {
        var s = raw.trim().lowercase()
        s = s.substringAfter("://")
        s = s.substringBefore('/').substringBefore('?').substringBefore('#')
        s = s.substringAfter('@')
        s = s.substringBefore(':')
        s = s.removePrefix("www.").trimEnd('.')
        return if (s.length <= 253 && DOMAIN.matches(s)) s else ""
    }

    fun toMin(v: String): Int {
        val p = v.split(":")
        return (p.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0)
    }

    // 월=0 ... 일=6
    fun dayIndex(cal: Calendar): Int = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7

    // 요일 + 시간 구간 안에 지금이 들어가는지. 자정을 넘기는 구간(22:00~06:00)은
    // 자정 이후 부분을 '전날 요일' 기준으로 본다 (금요일 밤 규칙은 토요일 새벽까지).
    fun inWindow(days: BooleanArray, startMin: Int, endMin: Int, cal: Calendar): Boolean {
        if (startMin == endMin) return false
        val minute = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val d = dayIndex(cal)
        return if (startMin < endMin) {
            days[d] && minute in startMin until endMin
        } else {
            (days[d] && minute >= startMin) || (days[(d + 6) % 7] && minute < endMin)
        }
    }

    // 전화·긴급통화·알람·설정은 기간 차단/규칙 선택 목록에서 뺀다
    fun isEssential(pkg: String): Boolean =
        pkg == "com.android.settings" || pkg == "com.samsung.android.settings" ||
            listOf("dialer", "incallui", "telecom", "emergency", "clockpackage", "deskclock").any { pkg.contains(it) }

    // ---------- 자동 규칙 ----------
    fun rules(p: SharedPreferences): List<Rule> {
        val out = ArrayList<Rule>()
        try {
            val arr = JSONArray(p.getString("rules_json", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val dj = o.getJSONArray("days")
                val aj = o.getJSONArray("apps")
                val sj = o.optJSONArray("sites")
                out.add(
                    Rule(
                        o.getString("id"),
                        o.optString("name"),
                        BooleanArray(7) { dj.optBoolean(it, false) },
                        o.getString("start"),
                        o.getString("end"),
                        (0 until aj.length()).map { aj.getString(it) }.toSet(),
                        o.optBoolean("on", true),
                        if (sj == null) emptySet() else (0 until sj.length()).map { sj.getString(it) }.toSet()
                    )
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun ruleHit(r: Rule, cal: Calendar): Boolean =
        r.on && (r.apps.isNotEmpty() || r.sites.isNotEmpty()) && inWindow(r.days, toMin(r.start), toMin(r.end), cal)

    // ---------- 앱별/기본 시간 ----------
    // 앱마다 따로 정한 요일·시간이 있으면 그걸 쓰고, 없으면 기본 요일·시간을 쓴다
    // 기본 요일·시간(앱별 설정이 없을 때 쓰는 것)에 지금이 들어가는지
    fun globalHit(p: SharedPreferences, cal: Calendar): Boolean {
        val days = BooleanArray(7) { p.getBoolean("day_$it", it < 5) }
        return inWindow(days, toMin(p.getString("start", "16:00") ?: "16:00"), toMin(p.getString("end", "18:00") ?: "18:00"), cal)
    }

    fun appScheduleHit(p: SharedPreferences, pkg: String, cal: Calendar): Boolean {
        val ad = p.getString("app_days_$pkg", "") ?: ""
        val days = BooleanArray(7) { if (ad.length == 7) ad[it] == '1' else p.getBoolean("day_$it", it < 5) }
        val c = (p.getString("app_time_$pkg", "") ?: "").split("-")
        val start = if (c.size == 2) toMin(c[0]) else toMin(p.getString("start", "16:00") ?: "16:00")
        val end = if (c.size == 2) toMin(c[1]) else toMin(p.getString("end", "18:00") ?: "18:00")
        return inWindow(days, start, end, cal)
    }

    // ---------- 기간 차단 ----------
    fun periodActive(p: SharedPreferences): Boolean =
        p.getLong("period_until", 0L) > System.currentTimeMillis()

    fun periodPaused(p: SharedPreferences): Boolean =
        System.currentTimeMillis() < p.getLong("period_pause_until", 0L)

    fun periodApps(p: SharedPreferences): Set<String> =
        HashSet(p.getStringSet("period_pkgs", emptySet()) ?: emptySet())

    fun periodSites(p: SharedPreferences): Set<String> =
        HashSet(p.getStringSet("period_sites", emptySet()) ?: emptySet())

    fun globalSites(p: SharedPreferences): Set<String> =
        HashSet(p.getStringSet("sites", emptySet()) ?: emptySet())

    // 해제 불가 시간대(기본 22:00~06:00)인지
    fun inUnlockBan(p: SharedPreferences, cal: Calendar = Calendar.getInstance()): Boolean {
        val s = toMin(p.getString("ban_start", "22:00") ?: "22:00")
        val e = toMin(p.getString("ban_end", "06:00") ?: "06:00")
        if (s == e) return false
        val m = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return if (s < e) m in s until e else m >= s || m < e
    }

    // ---------- 종합 판단 ----------
    fun isBlockedNow(p: SharedPreferences, pkg: String): Boolean {
        // 기간 차단은 비상 쉬기로도 풀리지 않는다
        if (periodActive(p) && !periodPaused(p) && pkg in periodApps(p)) return true
        if (System.currentTimeMillis() < p.getLong("break_until", 0L)) return false
        val cal = Calendar.getInstance()
        val sel = p.getStringSet("packages", emptySet()) ?: emptySet()
        if (pkg in sel && appScheduleHit(p, pkg, cal)) return true
        return rules(p).any { pkg in it.apps && ruleHit(it, cal) }
    }

    // 지금 막아야 하는 사이트(도메인) 목록. 사이트 차단 VPN이 DNS 질문마다 확인한다.
    fun activeSites(p: SharedPreferences): Set<String> {
        val out = HashSet<String>()
        if (periodActive(p) && !periodPaused(p)) out.addAll(periodSites(p))
        if (System.currentTimeMillis() < p.getLong("break_until", 0L)) return out
        val cal = Calendar.getInstance()
        if (globalHit(p, cal)) out.addAll(globalSites(p))
        rules(p).forEach { if (ruleHit(it, cal)) out.addAll(it.sites) }
        return out
    }

    // 지금 차단 중인 것이 하나라도 있는지 (강력 모드 잠금 판단에 사용)
    fun anyBlockedNow(p: SharedPreferences): Boolean {
        if (periodActive(p) && !periodPaused(p) && (periodApps(p).isNotEmpty() || periodSites(p).isNotEmpty())) return true
        if (System.currentTimeMillis() < p.getLong("break_until", 0L)) return false
        val cal = Calendar.getInstance()
        val sel = p.getStringSet("packages", emptySet()) ?: emptySet()
        if (sel.any { appScheduleHit(p, it, cal) }) return true
        if (globalSites(p).isNotEmpty() && globalHit(p, cal)) return true
        return rules(p).any { ruleHit(it, cal) }
    }
}
