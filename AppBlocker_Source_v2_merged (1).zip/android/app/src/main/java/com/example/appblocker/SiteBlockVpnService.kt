package com.example.appblocker

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

// 사이트 차단: 폰의 DNS 질문만 이 VPN으로 받아서, 막아야 하는 주소면 "없는 주소"로 답하고
// 나머지는 그대로 진짜 DNS 서버로 전달한다. 일반 데이터는 VPN을 거치지 않는다.
class SiteBlockVpnService : VpnService() {
    companion object {
        @Volatile
        var running = false
        private const val TUN_ADDR = "10.111.222.1"
        private const val FAKE_DNS = "10.111.222.2"
        private val UPSTREAMS = arrayOf("1.1.1.1", "8.8.8.8")
    }

    private var tun: ParcelFileDescriptor? = null

    @Volatile
    private var alive = false
    private val pool = Executors.newFixedThreadPool(6)
    private var cache: Set<String> = emptySet()
    private var cacheAt = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences("rules", MODE_PRIVATE)
        if (!prefs.getBoolean("site_vpn_on", false)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!alive) start()
        return START_STICKY
    }

    private fun start() {
        val builder = VpnService.Builder()
            .setSession("AppBlocker 사이트 차단")
            .setMtu(1500)
            .addAddress(TUN_ADDR, 32)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32)
            .setBlocking(true)
        val fd = try {
            builder.establish()
        } catch (_: Exception) {
            null
        }
        if (fd == null) {
            stopSelf()
            return
        }
        tun = fd
        alive = true
        running = true
        Thread({ loop(fd) }, "site-block").start()
    }

    private fun loop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (alive) {
                val n = input.read(buf)
                if (n < 0) break
                if (n > 0) handle(buf, n, output)
            }
        } catch (_: Exception) {
        } finally {
            stopAll()
        }
    }

    private fun handle(p: ByteArray, len: Int, out: FileOutputStream) {
        if (len < 28) return
        if ((p[0].toInt() shr 4) != 4) return
        val ihl = (p[0].toInt() and 0x0f) * 4
        if (ihl < 20 || len < ihl + 8) return
        if (p[9].toInt() != 17) return // UDP만
        if (p[16] != 10.toByte() || p[17] != 111.toByte() || p[18] != 222.toByte() || p[19] != 2.toByte()) return
        val srcPort = ((p[ihl].toInt() and 0xff) shl 8) or (p[ihl + 1].toInt() and 0xff)
        val dstPort = ((p[ihl + 2].toInt() and 0xff) shl 8) or (p[ihl + 3].toInt() and 0xff)
        if (dstPort != 53) return
        val udpLen = ((p[ihl + 4].toInt() and 0xff) shl 8) or (p[ihl + 5].toInt() and 0xff)
        val payloadLen = minOf(udpLen - 8, len - ihl - 8)
        if (payloadLen < 12) return
        val dns = p.copyOfRange(ihl + 8, ihl + 8 + payloadLen)
        val srcIp = p.copyOfRange(12, 16)
        val q = parseQuestion(dns) ?: return
        if (isBlocked(q.first)) {
            reply(blockedAnswer(dns, q.second), srcIp, srcPort, out)
        } else {
            pool.execute { forward(dns, srcIp, srcPort, out) }
        }
    }

    // DNS 질문에서 (도메인, 질문 부분이 끝나는 위치)를 꺼낸다
    private fun parseQuestion(d: ByteArray): Pair<String, Int>? {
        var i = 12
        val sb = StringBuilder()
        while (i < d.size) {
            val l = d[i].toInt() and 0xff
            if (l == 0) {
                val end = i + 1 + 4
                if (sb.isEmpty() || end > d.size) return null
                return Pair(sb.toString().lowercase(), end)
            }
            if ((l and 0xc0) != 0) return null
            if (i + 1 + l > d.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(d, i + 1, l, Charsets.ISO_8859_1))
            i += l + 1
        }
        return null
    }

    private fun isBlocked(name: String): Boolean {
        val now = System.currentTimeMillis()
        if (now - cacheAt > 2000L) {
            cache = BlockLogic.activeSites(getSharedPreferences("rules", MODE_PRIVATE))
            cacheAt = now
        }
        return cache.any { name == it || name.endsWith(".$it") }
    }

    // "그런 주소 없음(NXDOMAIN)" 답
    private fun blockedAnswer(dns: ByteArray, qEnd: Int): ByteArray {
        val r = dns.copyOfRange(0, qEnd)
        r[2] = (0x80 or (dns[2].toInt() and 0x01)).toByte() // 응답 표시, 질문의 RD 유지
        r[3] = (0x80 or 0x03).toByte() // RA, RCODE=3
        for (k in 6..11) r[k] = 0
        return r
    }

    private fun forward(dns: ByteArray, srcIp: ByteArray, srcPort: Int, out: FileOutputStream) {
        for (server in UPSTREAMS) {
            var s: DatagramSocket? = null
            try {
                s = DatagramSocket()
                protect(s) // 이 소켓은 VPN을 거치지 않고 바로 나간다
                s.soTimeout = 3000
                s.send(DatagramPacket(dns, dns.size, InetAddress.getByName(server), 53))
                val buf = ByteArray(4096)
                val pk = DatagramPacket(buf, buf.size)
                s.receive(pk)
                reply(buf.copyOf(pk.length), srcIp, srcPort, out)
                return
            } catch (_: Exception) {
            } finally {
                try {
                    s?.close()
                } catch (_: Exception) {
                }
            }
        }
    }

    // DNS 답을 IP/UDP 패킷으로 감싸서 폰으로 돌려준다
    private fun reply(dns: ByteArray, dstIp: ByteArray, dstPort: Int, out: FileOutputStream) {
        val total = 28 + dns.size
        val p = ByteArray(total)
        p[0] = 0x45
        p[2] = (total shr 8).toByte()
        p[3] = (total and 0xff).toByte()
        p[6] = 0x40
        p[8] = 64
        p[9] = 17
        p[12] = 10
        p[13] = 111
        p[14] = 222.toByte()
        p[15] = 2
        for (k in 0 until 4) p[16 + k] = dstIp[k]
        p[21] = 53
        p[22] = (dstPort shr 8).toByte()
        p[23] = (dstPort and 0xff).toByte()
        val udpLen = 8 + dns.size
        p[24] = (udpLen shr 8).toByte()
        p[25] = (udpLen and 0xff).toByte()
        System.arraycopy(dns, 0, p, 28, dns.size)
        var sum = 0
        for (k in 0 until 20 step 2) sum += ((p[k].toInt() and 0xff) shl 8) or (p[k + 1].toInt() and 0xff)
        while ((sum shr 16) != 0) sum = (sum and 0xffff) + (sum shr 16)
        val ck = sum.inv() and 0xffff
        p[10] = (ck shr 8).toByte()
        p[11] = (ck and 0xff).toByte()
        try {
            synchronized(out) { out.write(p) }
        } catch (_: Exception) {
        }
    }

    private fun stopAll() {
        alive = false
        running = false
        try {
            tun?.close()
        } catch (_: Exception) {
        }
        tun = null
    }

    override fun onRevoke() {
        stopAll()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopAll()
        pool.shutdownNow()
        super.onDestroy()
    }
}
