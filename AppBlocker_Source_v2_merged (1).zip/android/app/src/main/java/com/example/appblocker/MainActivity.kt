package com.example.appblocker

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("rules", MODE_PRIVATE) }
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { refreshPage() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.addJavascriptInterface(Bridge(), "Native")
        web.setOnApplyWindowInsetsListener { v, ins ->
            v.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
            ins
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    // VPN 연결 허용 창에서 돌아왔을 때
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 71) {
            if (resultCode == RESULT_OK) startService(Intent(this, SiteBlockVpnService::class.java))
            else prefs.edit().putBoolean("site_vpn_on", false).apply()
            refreshPage()
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            if (prefs.getBoolean("site_vpn_on", false) && !SiteBlockVpnService.running && VpnService.prepare(this) == null)
                startService(Intent(this, SiteBlockVpnService::class.java))
        } catch (_: Exception) {
        }
        refreshPage()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        registerReceiver(receiver, f)
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
    }

    private fun refreshPage() {
        runOnUiThread { web.evaluateJavascript("window.loadAll && loadAll()", null) }
    }

    private fun iconB64(d: Drawable): String {
        val s = 72
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, s, s)
        d.draw(Canvas(b))
        val o = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.PNG, 100, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    private fun selectedSet(): MutableSet<String> =
        (prefs.getStringSet("packages", emptySet()) ?: emptySet()).toMutableSet()

    private fun serviceOn(): Boolean =
        Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true

    // 강력 모드가 켜져 있고 지금이 차단 시간이면 해제/변경을 막는다
    private fun locked(): Boolean =
        prefs.getBoolean("strict", false) && serviceOn() && BlockLogic.anyBlockedNow(prefs)

    inner class Bridge {
        @JavascriptInterface
        fun getApps(): String {
            val sel = selectedSet()
            val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
            val arr = JSONArray()
            packageManager.queryIntentActivities(intent, 0)
                .filter { it.activityInfo.packageName != packageName }
                .distinctBy { it.activityInfo.packageName }
                .forEach { ri ->
                    val pkg = ri.activityInfo.packageName
                    arr.put(JSONObject().apply {
                        put("pkg", pkg)
                        put("label", ri.loadLabel(packageManager).toString())
                        put("on", pkg in sel)
                        put("t", prefs.getString("app_time_$pkg", ""))
                        put("d", prefs.getString("app_days_$pkg", ""))
                        put("ess", BlockLogic.isEssential(pkg))
                        put("icon", iconB64(ri.loadIcon(packageManager)))
                    })
                }
            return arr.toString()
        }

        @JavascriptInterface
        fun setBlocked(pkg: String, on: Boolean): String {
            if (!on && locked()) return "locked"
            val s = selectedSet()
            if (on) s.add(pkg) else s.remove(pkg)
            prefs.edit().putStringSet("packages", s).apply()
            return "ok"
        }

        @JavascriptInterface
        fun startBreak(): String {
            val now = System.currentTimeMillis()
            if (now - prefs.getLong("break_last", 0L) < 3_600_000L) return "cool"
            prefs.edit().putLong("break_until", now + 900_000L).putLong("break_last", now).apply()
            return "ok"
        }

        @JavascriptInterface
        fun endBreak(): String {
            prefs.edit().putLong("break_until", 0L).apply()
            return "ok"
        }

        @JavascriptInterface
        fun startLock(kind: String): String {
            if (!serviceOn()) return "noservice"
            val now = System.currentTimeMillis()
            if (prefs.getLong("lock_until", 0L) > now) return "already"
            val ms = when (kind) { "sleep" -> prefs.getInt("sleep_min", 480) * 60_000L; "test" -> 60_000L; else -> prefs.getInt("study_min", 120) * 60_000L }
            prefs.edit().putLong("lock_until", now + ms).putString("lock_kind", kind).apply()
            return "ok"
        }

        @JavascriptInterface
        fun getStrict(): Boolean = prefs.getBoolean("strict", false)

        @JavascriptInterface
        fun setStrict(on: Boolean): String {
            if (!on && locked()) return "locked"
            prefs.edit().putBoolean("strict", on).apply()
            return "ok"
        }

        @JavascriptInterface
        fun getSchedule(): String {
            val days = JSONArray()
            for (i in 0..6) days.put(prefs.getBoolean("day_$i", i < 5))
            return JSONObject().apply {
                put("days", days)
                put("start", prefs.getString("start", "16:00"))
                put("end", prefs.getString("end", "18:00"))
                put("studyMin", prefs.getInt("study_min", 120))
                put("sleepMin", prefs.getInt("sleep_min", 480))
            }.toString()
        }

        // 앱별 요일/시간. 요일 문자열은 월~일 7칸의 0/1 (예: "1111100"), 비우면 기본 요일 사용.
        // 시작/종료를 둘 다 비우면 기본 시간 사용. 셋 다 비우면 앱별 설정 삭제.
        @JavascriptInterface
        fun setAppSchedule(pkg: String, daysStr: String, start: String, end: String): String {
            if (locked()) return "locked"
            val e = prefs.edit()
            if (daysStr.isEmpty()) e.remove("app_days_$pkg")
            else {
                if (!Regex("^[01]{7}$").matches(daysStr) || !daysStr.contains('1')) return "bad"
                e.putString("app_days_$pkg", daysStr)
            }
            if (start.isEmpty() && end.isEmpty()) e.remove("app_time_$pkg")
            else {
                if (!BlockLogic.validTime(start) || !BlockLogic.validTime(end) || start == end) return "bad"
                e.putString("app_time_$pkg", "$start-$end")
            }
            e.apply()
            return "ok"
        }

        @JavascriptInterface
        fun setDurations(studyMin: Int, sleepMin: Int): String {
            if (locked() || prefs.getLong("lock_until", 0L) > System.currentTimeMillis()) return "locked"
            prefs.edit().putInt("study_min", studyMin.coerceIn(10, 1440)).putInt("sleep_min", sleepMin.coerceIn(10, 1440)).apply()
            return "ok"
        }

        @JavascriptInterface
        fun saveSchedule(daysJson: String, start: String, end: String): String {
            if (locked()) return "locked"
            val ok = Regex("^([01]\\d|2[0-3]):[0-5]\\d$")
            if (!ok.matches(start) || !ok.matches(end) || start == end) return "bad"
            val days = JSONArray(daysJson)
            val e = prefs.edit().putString("start", start).putString("end", end)
            for (i in 0..6) e.putBoolean("day_$i", days.optBoolean(i, i < 5))
            e.apply()
            return "ok"
        }

        @JavascriptInterface
        fun getStatus(): String {
            val enabled = serviceOn()
            return JSONObject().apply {
                put("strict", prefs.getBoolean("strict", false))
                val left = prefs.getLong("break_until", 0L) - System.currentTimeMillis()
                put("breakLeft", if (left > 0) ((left + 59_999) / 60_000).toInt() else 0)
                val lockLeft = prefs.getLong("lock_until", 0L) - System.currentTimeMillis()
                put("lockLeft", if (lockLeft > 0) ((lockLeft + 59_999) / 60_000).toInt() else 0)
                put("lockKind", prefs.getString("lock_kind", "study"))
                put("enabled", enabled)
                put("blocking", enabled && BlockLogic.anyBlockedNow(prefs))
                val now = System.currentTimeMillis()
                val perLeft = prefs.getLong("period_until", 0L) - now
                put("periodLeft", if (perLeft > 0) ((perLeft + 59_999) / 60_000).toInt() else 0)
                val pauseLeft = prefs.getLong("period_pause_until", 0L) - now
                put("periodPause", if (pauseLeft > 0 && perLeft > 0) ((pauseLeft + 59_999) / 60_000).toInt() else 0)
                put("unlockBan", BlockLogic.inUnlockBan(prefs))
            }.toString()
        }

        // ---------- 자동 차단 규칙 (이름 붙인 요일·시간 규칙) ----------
        @JavascriptInterface
        fun getRules(): String = prefs.getString("rules_json", "[]") ?: "[]"

        @JavascriptInterface
        fun saveRule(json: String): String {
            if (locked()) return "locked"
            val o = try { JSONObject(json) } catch (_: Exception) { return "bad" }
            val name = o.optString("name").trim()
            val start = o.optString("start")
            val end = o.optString("end")
            val days = o.optJSONArray("days")
            val apps = o.optJSONArray("apps")
            if (name.isEmpty() || name.length > 20) return "name"
            if (!BlockLogic.validTime(start) || !BlockLogic.validTime(end) || start == end) return "time"
            if (days == null || days.length() != 7 || (0..6).none { days.optBoolean(it) }) return "days"
            val siteSet = LinkedHashSet<String>()
            val sj = o.optJSONArray("sites")
            if (sj != null) for (i in 0 until sj.length()) {
                val d = BlockLogic.normalizeSite(sj.optString(i))
                if (d.isNotEmpty()) siteSet.add(d)
            }
            if (siteSet.size > 50) return "bad"
            if (apps == null || (apps.length() == 0 && siteSet.isEmpty())) return "apps"
            val list = JSONArray(prefs.getString("rules_json", "[]"))
            var id = o.optString("id")
            val exists = (0 until list.length()).any { list.getJSONObject(it).optString("id") == id }
            if (id.isEmpty() || !exists) {
                if (list.length() >= 20) return "max"
                id = "r" + System.currentTimeMillis()
            }
            val clean = JSONObject().apply {
                put("id", id); put("name", name)
                put("days", JSONArray().also { a -> (0..6).forEach { a.put(days.optBoolean(it)) } })
                put("start", start); put("end", end)
                put("apps", apps); put("sites", JSONArray(siteSet.toList())); put("on", o.optBoolean("on", true))
            }
            val out = JSONArray()
            var replaced = false
            for (i in 0 until list.length()) {
                val r = list.getJSONObject(i)
                if (r.optString("id") == id) { out.put(clean); replaced = true } else out.put(r)
            }
            if (!replaced) out.put(clean)
            prefs.edit().putString("rules_json", out.toString()).apply()
            return "ok"
        }

        @JavascriptInterface
        fun setRuleEnabled(id: String, on: Boolean): String {
            if (!on && locked()) return "locked"
            val list = JSONArray(prefs.getString("rules_json", "[]"))
            for (i in 0 until list.length()) {
                val r = list.getJSONObject(i)
                if (r.optString("id") == id) r.put("on", on)
            }
            prefs.edit().putString("rules_json", list.toString()).apply()
            return "ok"
        }

        @JavascriptInterface
        fun deleteRule(id: String): String {
            if (locked()) return "locked"
            val list = JSONArray(prefs.getString("rules_json", "[]"))
            val out = JSONArray()
            for (i in 0 until list.length()) {
                val r = list.getJSONObject(i)
                if (r.optString("id") != id) out.put(r)
            }
            prefs.edit().putString("rules_json", out.toString()).apply()
            return "ok"
        }

        // ---------- 기간 차단 (며칠·몇 주·몇 달) ----------
        @JavascriptInterface
        fun getPeriod(): String {
            val now = System.currentTimeMillis()
            val until = prefs.getLong("period_until", 0L)
            val active = until > now
            val pauseLeft = prefs.getLong("period_pause_until", 0L) - now
            return JSONObject().apply {
                put("active", active)
                put("leftMin", if (active) ((until - now + 59_999) / 60_000).toInt() else 0)
                put("totalDays", prefs.getInt("period_days", 0))
                put("apps", JSONArray(BlockLogic.periodApps(prefs).toList()))
                put("sites", JSONArray(BlockLogic.periodSites(prefs).sorted()))
                put("used", prefs.getBoolean("period_unlock_used", false))
                put("inBan", BlockLogic.inUnlockBan(prefs))
                put("pauseLeft", if (active && pauseLeft > 0) ((pauseLeft + 59_999) / 60_000).toInt() else 0)
                put("penaltyDays", prefs.getInt("period_penalty_days", 0))
                put("banStart", prefs.getString("ban_start", "22:00"))
                put("banEnd", prefs.getString("ban_end", "06:00"))
            }.toString()
        }

        @JavascriptInterface
        fun startPeriod(appsJson: String, sitesJson: String, days: Int): String {
            if (!serviceOn()) return "noservice"
            val now = System.currentTimeMillis()
            if (prefs.getLong("period_until", 0L) > now) return "already"
            val arr = try { JSONArray(appsJson) } catch (_: Exception) { return "bad" }
            val set = (0 until arr.length()).map { arr.getString(it) }
                .filter { it != packageName && !BlockLogic.isEssential(it) }.toSet()
            val sarr = try { JSONArray(sitesJson) } catch (_: Exception) { return "bad" }
            val sites = (0 until sarr.length()).map { BlockLogic.normalizeSite(sarr.optString(it)) }
                .filter { it.isNotEmpty() }.toSet()
            if (set.isEmpty() && sites.isEmpty()) return "noapps"
            if (sites.size > 100) return "bad"
            if (sites.isNotEmpty() && !(prefs.getBoolean("site_vpn_on", false) && SiteBlockVpnService.running)) return "novpn"
            if (days < 1 || days > 365) return "bad"
            // 지난 기간에 중간 해제를 썼다면 그만큼 이번 기간에 더해진다
            val total = (days + prefs.getInt("period_penalty_days", 0)).coerceAtMost(730)
            prefs.edit()
                .putStringSet("period_pkgs", set)
                .putStringSet("period_sites", sites)
                .putLong("period_until", now + total * 86_400_000L)
                .putLong("period_pause_until", 0L)
                .putBoolean("period_unlock_used", false)
                .putInt("period_days", total)
                .putInt("period_penalty_days", 0)
                .apply()
            return "ok"
        }

        // mode: "pause" = 30분만 풀기(그 뒤 다시 잠김), "end" = 기간 차단 끝내기. 기간당 1번만.
        @JavascriptInterface
        fun unlockPeriod(mode: String): String {
            val now = System.currentTimeMillis()
            if (prefs.getLong("period_until", 0L) <= now) return "none"
            if (prefs.getBoolean("period_unlock_used", false)) return "used"
            if (BlockLogic.inUnlockBan(prefs)) return "ban"
            val total = prefs.getInt("period_days", 1)
            val extra = ((total + 1) / 2).coerceIn(1, 365) // 다음 기간에 절반(올림)만큼 추가
            val e = prefs.edit().putBoolean("period_unlock_used", true).putInt("period_penalty_days", extra)
            if (mode == "end") e.putLong("period_until", 0L).putLong("period_pause_until", 0L)
            else e.putLong("period_pause_until", now + BlockLogic.PAUSE_MS)
            e.apply()
            return "ok"
        }

        @JavascriptInterface
        fun setUnlockBan(start: String, end: String): String {
            if (prefs.getLong("period_until", 0L) > System.currentTimeMillis()) return "locked"
            if (!BlockLogic.validTime(start) || !BlockLogic.validTime(end) || start == end) return "bad"
            prefs.edit().putString("ban_start", start).putString("ban_end", end).apply()
            return "ok"
        }

        // ---------- 사이트 차단 ----------
        @JavascriptInterface
        fun normalizeSite(raw: String): String = BlockLogic.normalizeSite(raw)

        @JavascriptInterface
        fun getSites(): String = JSONArray(BlockLogic.globalSites(prefs).sorted()).toString()

        @JavascriptInterface
        fun addSite(raw: String): String {
            val d = BlockLogic.normalizeSite(raw)
            if (d.isEmpty()) return "bad"
            val cur = BlockLogic.globalSites(prefs).toMutableSet()
            if (cur.size >= 200) return "max"
            cur.add(d)
            prefs.edit().putStringSet("sites", cur).apply()
            return "ok"
        }

        @JavascriptInterface
        fun removeSite(raw: String): String {
            if (locked()) return "locked"
            val cur = BlockLogic.globalSites(prefs).toMutableSet()
            cur.remove(raw)
            prefs.edit().putStringSet("sites", cur).apply()
            return "ok"
        }

        @JavascriptInterface
        fun siteStatus(): String = JSONObject().apply {
            put("on", prefs.getBoolean("site_vpn_on", false))
            put("running", SiteBlockVpnService.running)
        }.toString()

        @JavascriptInterface
        fun enableSiteBlock(): String {
            prefs.edit().putBoolean("site_vpn_on", true).apply()
            val i = VpnService.prepare(this@MainActivity)
            if (i != null) {
                runOnUiThread { startActivityForResult(i, 71) }
                return "ask"
            }
            startService(Intent(this@MainActivity, SiteBlockVpnService::class.java))
            return "ok"
        }

        @JavascriptInterface
        fun disableSiteBlock(): String {
            // 기간 차단에 사이트가 들어 있거나 강력 모드로 잠겨 있으면 끌 수 없다
            if (BlockLogic.periodActive(prefs) && BlockLogic.periodSites(prefs).isNotEmpty()) return "locked"
            if (locked()) return "locked"
            prefs.edit().putBoolean("site_vpn_on", false).apply()
            stopService(Intent(this@MainActivity, SiteBlockVpnService::class.java))
            return "ok"
        }

        @JavascriptInterface
        fun openAccessibility() {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        @JavascriptInterface
        fun openDetails() {
            val i = Intent("android.settings.ACCESSIBILITY_DETAILS_SETTINGS")
            i.data = Uri.parse("package:$packageName")
            try { startActivity(i) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
    }
}
